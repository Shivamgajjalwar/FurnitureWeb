<!DOCTYPE html>
<html>
<head>
    <title>Product List</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
    <div class="container mt-5">
        <div class="row">
            <?php
            $servername = "localhost";
            $username = "root";
            $password = "";
            $dbname = "furniture";

            // Create connection
            $conn = new mysqli($servername, $username, $password, $dbname);

            // Check connection
            if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);
            }

            $sql = "SELECT * FROM dipak"; // SQL query to select all rows from 'dipak' table

            $result = $conn->query($sql);

            if ($result->num_rows > 0) {
                // Output data of each row
                while($row = $result->fetch_assoc()) {
                    // Assign different colors to cards based on product ID
                    $card_color = $row["id"] % 2 == 0 ? "bg-info" : "bg-success";

                    echo "<div class='col-md-4 mt-3'>
                            <div class='card $card_color text-white'>
                                <div class='card-body'>
                                    <h5 class='card-title'>" . $row["name"] . "</h5>
                                    <p class='card-text'>" . $row["info"] . "</p>
                                    <p class='card-text'>Price: $" . $row["price"] . "</p>
                                    <form method='post'>
                                        <input type='hidden' name='product_id' value='" . $row["id"] . "'>
                                        <button type='submit' class='btn btn-light' name='delete'>Delete</button>
                                    </form>
                                </div>
                            </div>
                        </div>";
                }
            } else {
                echo "0 results";
            }

            if(isset($_POST["delete"])) {
                $product_id = $_POST["product_id"];
                $delete_sql = "DELETE FROM dipak WHERE id=$product_id";
                if ($conn->query($delete_sql) === TRUE) {
                    echo "<div class='col-md-12 mt-3'>
                            <div class='alert alert-success' role='alert'>
                                Product deleted successfully.
                            </div>
                        </div>";
                } else {
                    echo "<div class='col-md-12 mt-3'>
                            <div class='alert alert-danger' role='alert'>
                                Error deleting product: " . $conn->error . "
                            </div>
                        </div>";
                }
            }

            $conn->close();
            ?>
        </div>
    </div>
</body>
</html>
