<?php
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "furniture";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $items = $_POST['items'];
    $name = $_POST['name'];
    $info = $_POST['info'];
    $price = $_POST['price'];

    // SQL query to insert data into the database
    $sql = "INSERT INTO dipak (items, name, info, price)
            VALUES ('$items', '$name', '$info', $price)";

    if ($conn->query($sql) === TRUE) {
        echo "New record created successfully";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

$conn->close();
?>
